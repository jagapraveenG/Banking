module bankingApp {
    requires java.sql;

    exports Banking; // Replace "com.yourpackage" with the package containing your Java classes
}
